import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.function.Consumer;
import javafx.application.Platform;
import javafx.scene.control.ListView;
import javafx.util.Pair;

public class Server
{
	int count = 1;

	ArrayList<ClientThread> clients = new ArrayList<ClientThread>();

	ArrayList<Game> games = new ArrayList<Game>();

	TheServer server;

	private Consumer<Serializable> callback;

	private String getTime()
	{
		return java.time.LocalTime.now().format(java.time.format.DateTimeFormatter.ofPattern("HH:mm"));
	}
	Server(Consumer<Serializable> call)
	{
		callback = call;
		server = new TheServer();
		server.start();
	}

	public class TheServer extends Thread
	{

		public void run()
		{
			try(ServerSocket mysocket = new ServerSocket(5555);){
				System.out.println("Server is waiting for a client!");

				while(true)
				{
					ClientThread c = new ClientThread(mysocket.accept(), count);
					callback.accept("||CONNECTION|| A client has connected to server: " + "client #" + count + " at " + getTime());
					clients.add(c);
					c.start();

					count++;

				}
			}//end of try
			catch(Exception e)
			{
				callback.accept("Server socket did not launch");
			}
		}//end of while
	}

	class ClientThread extends Thread
	{
		Socket connection;
		int count;
		ObjectInputStream inputStream;
		ObjectOutputStream outputStream;
		String username;

		Boolean nameTaken = false;

		ClientThread(Socket s, int count)
		{
			this.connection = s;
			this.count = count;
		}
		public void run()
		{
			try
			{
				outputStream = new ObjectOutputStream(connection.getOutputStream());
				inputStream = new ObjectInputStream(connection.getInputStream());
				connection.setTcpNoDelay(true);
			}
			catch (Exception e)
			{
				System.out.println("Streams not open");
				return;
			}

			while(true)
			{
				try{
					Object theMessage = inputStream.readObject();
					if(theMessage instanceof String)
					{
						String m = (String) theMessage;
						if (m.equals("REQUEST_USER_LIST")) {
							ArrayList<String> usernames = new ArrayList<>();
							for (ClientThread t : clients) {
								if (t.username != null && !t.username.isEmpty()) {
									usernames.add(t.username);
								}
							}
							this.outputStream.writeObject(usernames);
							outputStream.reset();
						}
						else if(m.equals("REQUEST_GAME_LIST"))
						{
							this.outputStream.writeObject(games);
							outputStream.reset();
						} else {
							String[] parts = m.split(" ", 2);
							nameTaken = false;
							if (parts.length > 1 && "USERNAME".equals(parts[0]))
							{
								String username = parts[1];
								for (ClientThread t : clients) {
									if (t.username != null && t.username.equals(username)) {
										this.nameTaken = true;
										break;
									}
								}
								if (!nameTaken) {
									this.username = parts[1];
								}
								this.outputStream.writeObject(nameTaken);
								outputStream.reset();
							}
							else
							{
								String theTitle = parts[1];
								for(Game indGame: games)
								{
									if(indGame.title.equals(theTitle))
									{
										this.outputStream.writeObject(indGame);
										outputStream.reset();
										break;
									}
								}
							}
						}
					}
					else if(theMessage instanceof Game)
					{
						Game messageGame = (Game)theMessage;
						int count = 1;
						for(Game indGame: games)
						{
							if(indGame.title.contains(messageGame.title))
							{
								count++;
							}
						}
						if(count != 1)
						{
							messageGame.title = messageGame.title + " " + count;
						}
						games.add((Game)theMessage);
					}
					else if(theMessage instanceof Pair)
					{
						Pair<String, Game> messageGame = (Pair<String, Game>) theMessage;
						if(messageGame.getKey().equals("NEEDS_RETURN"))
						{
							for (int i = 0; i < games.size(); i++)
							{
								Game indGame = games.get(i);
								if (indGame.title.equals(messageGame.getValue().title))
								{
									games.set(i, messageGame.getValue());
									Pair<String, Game> toReturn = new Pair<>("RETURNED", games.get(i));
									for(ClientThread c: clients)
									{
										if((c.username.equals(toReturn.getValue().user1) || c.username.equals(toReturn.getValue().user2)) && !c.username.equals("AI"))
										{
											c.outputStream.writeObject(toReturn);
											outputStream.reset();
										}
									}
									break;
								}
							}
						}
						else if(messageGame.getKey().equals("GAME_DONE"))
						{
							for (int i = 0; i < games.size(); i++)
							{
								Game indGame = games.get(i);
								if (indGame.title.equals(messageGame.getValue().title))
								{
									games.remove(indGame);
								}
							}
						}
						else
						{
							for (int i = 0; i < games.size(); i++)
							{
								Game indGame = games.get(i);
								if (indGame.title.equals(messageGame.getKey()))
								{
									games.set(i, messageGame.getValue());
									break;
								}
							}
						}
					}
				}
				catch(Exception e)
				{
					callback.accept("||DISCONNECTION|| OOOOPPs...Something wrong with the socket from " + this.username + "....closing down!");
					clients.remove(this);
					break;
				}
			}
		}
	}//end of client thread
}





