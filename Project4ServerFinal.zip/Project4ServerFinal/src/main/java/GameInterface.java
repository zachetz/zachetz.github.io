import javafx.event.EventHandler;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.CornerRadii;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

import java.util.concurrent.TimeUnit;

public class GameInterface
{
    private GridPane player1GridPane;
    private GridPane player2GridPane;
    private boolean clicked = false;
    public Game g;
    public int currX;
    public int currY;
    public int clickCount = 0;
    public GameInterface(Game game){
        this.g = game;
    }

    public GridPane displayUser1Board()
    {
        player1GridPane = updateGridPane(g.player1Board);
        return player1GridPane;
    }

    public GridPane displayUser2Board()
    {
        player2GridPane = updateGridPane2(g.player2Board);
        return player2GridPane;
    }

    public GridPane displayUser1BoardForUser2()
    {
        player1GridPane = updateGridPane2(g.player1Board);
        return player1GridPane;
    }

    public GridPane displayUser2BoardForUser2()
    {
        player2GridPane = updateGridPane(g.player2Board);
        return player2GridPane;
    }

    private GridPane updateGridPane(char[][] board)
    {
        GridPane gridPane = new GridPane();
        for (int row = 0; row < board.length; row++)
        {
            for (int col = 0; col < board[row].length; col++)
            {
                Rectangle rectangle = new Rectangle(30, 30);
                rectangle.setStroke(Color.BLACK);
                if (Character.isLowerCase(board[row][col]) && Character.isAlphabetic(board[row][col]))
                {
                    rectangle.setFill(Color.BLACK);
                }
                else
                {
                    switch (board[row][col])
                    {
                        case '-':
                            rectangle.setFill(Color.LIGHTBLUE);
                            break;
                        case 'X':
                            rectangle.setFill(Color.RED);
                            break;
                        case 'O':
                            rectangle.setFill(Color.WHITE);
                            break;
                        default:
                            break;
                    }
                }
                gridPane.add(rectangle, col, row);
            }
        }
        return gridPane;
    }

    private GridPane updateGridPane2(char[][] board)
    {
        GridPane gridPane = new GridPane();
        for (int row = 0; row < board.length; row++)
        {
            for (int col = 0; col < board[row].length; col++)
            {
                Rectangle rectangle = new Rectangle(30, 30);
                rectangle.setStroke(Color.BLACK);
                rectangle.setFill(Color.LIGHTBLUE);
                ;
                int finalRow = row;
                int finalCol = col;
                rectangle.setOnMouseClicked(event ->
                {
                    clickCount++;
                    if(clickCount < 2)
                    {
                        rectangle.setFill(Color.GREEN);
                        currX = finalRow;
                        currY = finalCol;
                        if(g.isAIGame)
                        {
                            g.launchMissileUser1(finalRow, finalCol);
                            g.launchMissileAI();
                        }
                        else
                        {
                            if(g.turn.equals(g.user1))
                            {
                                g.launchMissileUser1(finalRow, finalCol);
                            }
                            else
                            {
                                g.launchMissileUser2(finalRow, finalCol);
                            }
                        }
                    }
                });

                if (!(Character.isLowerCase(board[row][col]) && Character.isAlphabetic(board[row][col])))
                {
                    switch (board[row][col])
                    {
                        case '-':
                            rectangle.setFill(Color.LIGHTBLUE);
                            break;
                        case 'X':
                            rectangle.setFill(Color.RED);
                            break;
                        case 'O':
                            rectangle.setFill(Color.WHITE);
                            break;
                        default:
                            break;
                    }
                }
                gridPane.add(rectangle, col, row);
            }
        }
        return gridPane;
    }

    private void addClickHandler(Rectangle rectangle)
    {
        rectangle.setOnMouseClicked(new EventHandler<MouseEvent>()
        {
            @Override
            public void handle(MouseEvent event)
            {
                if(!clicked)
                {
                    rectangle.setFill(Color.GREY);
                    clicked = true;
                    int currX = GridPane.getRowIndex(rectangle);
                    int currY = GridPane.getColumnIndex(rectangle);
                    removeClickHandler(rectangle);
                }
            }
        });
    }

    private void removeClickHandler(Rectangle rectangle)
    {
        rectangle.setOnMouseClicked(null);
    }
}


