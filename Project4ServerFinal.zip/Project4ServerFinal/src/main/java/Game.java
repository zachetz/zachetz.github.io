import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.util.Random;
import java.util.ArrayList;
import java.util.Random;
import java.io.Serializable;

public class Game implements Serializable
{
    public char[][] player1Board = new char[10][10];
    public char[][] player2Board = new char[10][10];
    public int p1BoatsLeft;
    public int p2BoatsLeft;
    public String user1;
    public String user2;
    public String title;
    public String turn;
    public boolean isAIGame = false;
    public boolean placedBoats1;
    public boolean placedBoats2;


    public Game(String user1, String user2)
    {
        this.user1 = user1;
        if(user2.equals("AI"))
        {
            this.isAIGame = true;
        }
        this.user2 = user2;
        this.player1Board = new char[10][10];
        this.player2Board = new char[10][10];
        this.player1Board = initializeBoard(player1Board);
        this.player2Board = initializeBoard(player2Board);
        this.title = user1 + " versus " + user2;
        this.p1BoatsLeft = 17;
        this.p2BoatsLeft = 17;
        this.turn = user1;
        this.placedBoats1 = false;
        this.placedBoats2 = false;
    }


    public char[][] initializeBoard(char[][] board)
    {
        for(int i = 0; i < 10; i++)
        {
            for(int j = 0; j < 10; j++)
            {
                board[i][j] = '-';
            }
        }
        return board;
    }

    public String getUser1()
    {
        return user1;
    }

    public String getUser2()
    {
        return user2;
    }
    public void updateBoard(char[][] board, int x, int y)
    {
        if(Character.isLowerCase(board[x][y]) && Character.isAlphabetic(board[x][y]))
        {
            board[x][y] = 'X';
            return;
        }
        board[x][y] = 'O';
    }
    public void launchMissileUser1(int x, int y)
    {
        if(Character.isAlphabetic(player2Board[x][y]) && Character.isLowerCase(player2Board[x][y]))
        {
            --p2BoatsLeft;
        }
        updateBoard(player2Board, x, y);
    }
    public void launchMissileUser2(int x, int y)
    {
        if(Character.isAlphabetic(player1Board[x][y]) && Character.isLowerCase(player1Board[x][y]))
        {
            --p1BoatsLeft;
        }
        updateBoard(player1Board, x, y);
    }

    public void launchMissileAI()
    {
        Random rand = new Random();
        int randX = rand.nextInt(10);
        int randY = rand.nextInt(10);
        while(player1Board[randX][randY] == 'X' || player1Board[randX][randY] == 'O')
        {
            randX = rand.nextInt(10);
            randY = rand.nextInt(10);
        }
        this.turn = user1;
        launchMissileUser2(randX, randY);
    }

    public void placeBoatsAI()
    {
        int[] shipSizes = {2, 3, 3, 4, 5};
        char[] shipLabels = {'d', 'c', 's', 'b', 'a'};

        for (int shipIndex = 0; shipIndex < shipSizes.length; shipIndex++)
        {
            placeShip(shipSizes[shipIndex], shipLabels[shipIndex]);
        }
        placedBoats2 = true;
        printBoard();
    }

    private void placeShip(int size, char label)
    {
        boolean placed = false;
        Random random = new Random();
        while (!placed) {
            int row = random.nextInt(player2Board.length);
            int col = random.nextInt(player2Board[0].length);
            boolean horizontal = random.nextBoolean();

            if (canPlaceShip(row, col, size, horizontal))
            {
                for (int i = 0; i < size; i++)
                {
                    if (horizontal)
                    {
                        player2Board[row][col + i] = label;
                    }
                    else
                    {
                        player2Board[row + i][col] = label;
                    }
                }
                placed = true;
            }
        }
    }

    private boolean canPlaceShip(int row, int col, int size, boolean horizontal)
    {
        if (horizontal)
        {
            if (col + size > player2Board[0].length) return false;
            for (int i = 0; i < size; i++)
            {
                if (player2Board[row][col + i] != '-') return false;
            }
        }
        else
        {
            if(row + size > player2Board.length) return false;
            for (int i = 0; i < size; i++)
            {
                if (player2Board[row + i][col] != '-') return false;
            }
        }
        return true;
    }
    public void printBoard()
    {
        for (int i = 0; i < player2Board.length; i++)
        {
            for (int j = 0; j < player2Board[i].length; j++)
            {
                System.out.print(player2Board[i][j] + " ");
            }
            System.out.println();
        }
    }
    public boolean gameDone()
    {
        if(p1BoatsLeft == 0){
            return true;
        }
        return p2BoatsLeft == 0;
    }

    public void placeBoat(char[][] board, int x, int y){
        board[x][y] = 'b';
    }
}